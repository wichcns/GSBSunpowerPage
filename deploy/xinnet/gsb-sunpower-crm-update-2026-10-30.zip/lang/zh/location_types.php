<?php

return ['PETROL_STATION' => '加油站', 'BUSINESS_DISTRICT' => '商业区', 'MALL' => '商场', 'OPEN_LAND' => '空地', 'OTHER' => '其他', 'open_map' => '打开地图'];
