<?php

return ['PETROL_STATION' => 'Petrol station', 'BUSINESS_DISTRICT' => 'Business district', 'MALL' => 'Mall', 'OPEN_LAND' => 'Open land', 'OTHER' => 'Other', 'open_map' => 'Open map'];
