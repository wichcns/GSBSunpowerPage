@php
    $items = [
        ['label' => __('nav.dashboard'), 'route' => 'crm.admin.dashboard', 'icon' => '⌁', 'permission' => 'dashboard.view'],
        ['label' => __('nav.my_work'), 'route' => 'crm.admin.my-work', 'icon' => '✓', 'permission' => 'work.view'],
        ['label' => __('nav.team_work'), 'route' => 'crm.admin.team-work', 'icon' => '◎', 'permission' => 'team.view'],
        ['label' => __('nav.sites'), 'route' => 'crm.admin.sites.index', 'icon' => '⌖', 'permission' => 'sites.view'],
        ['label' => __('nav.ownership'), 'route' => 'crm.admin.ownership.index', 'icon' => '◎', 'permission' => 'ownership.manage'],
        ['label' => __('nav.pipeline'), 'route' => 'crm.admin.pipeline.index', 'icon' => '↗', 'permission' => 'pipeline.stage'],
        ['label' => __('nav.contracts'), 'route' => 'crm.admin.contracts.index', 'icon' => '▣', 'permission' => 'contracts.view'],
        ['label' => __('nav.engineering'), 'route' => 'crm.admin.engineering.index', 'icon' => '⚙', 'permission' => 'engineering.manage'],
        ['label' => __('nav.activities'), 'route' => 'crm.admin.activities.index', 'icon' => '◷', 'permission' => 'activities.view'],
        ['label' => __('nav.reports'), 'route' => 'crm.admin.reports.index', 'icon' => '▤', 'permission' => 'reports.view'],
        ['label' => __('nav.integrations'), 'route' => 'crm.admin.integrations.index', 'icon' => '⌘', 'permission' => 'system.manage'],
        ['label' => __('nav.settings'), 'route' => 'crm.admin.settings.index', 'icon' => '☼', 'permission' => 'system.manage'],
    ];
@endphp

<aside id="admin-sidebar" class="crm-sidebar" aria-label="{{ __('nav.main_menu') }}">
    <a href="{{ route('crm.admin.dashboard') }}" class="crm-brand">
        <span>
            <img class="crm-brand__logo" src="{{ asset('crm-assets/gsb-ev-logo.png') }}" alt="GSB EV">
            <small>{{ __('nav.platform') }}</small>
        </span>
    </a>

    <nav class="crm-sidebar__nav" aria-label="{{ __('nav.system_menu') }}">
        <div role="group" aria-label="{{ __('nav_groups.common') }}">
        <p class="px-4 pb-2 text-xs font-semibold text-slate-400">{{ __('nav_groups.common') }}</p>
        @foreach (array_slice($items, 0, 2) as $item)
            @continue(!auth()->user()?->hasPermission($item['permission']))
            <a class="crm-nav-item {{ request()->routeIs($item['route']) ? 'is-active' : '' }}" href="{{ route($item['route']) }}">
                <span aria-hidden="true">{{ $item['icon'] }}</span><span>{{ $item['label'] }}</span>
            </a>
        @endforeach
        </div>
        @php($roleItems = array_values(array_filter(array_slice($items, 2), fn ($item) => auth()->user()?->hasPermission($item['permission']))))
        @if($roleItems !== [])
        <div role="group" aria-label="{{ __('nav_groups.role') }}" class="mt-5 border-t border-white/10 pt-4">
            <p class="px-4 pb-2 text-xs font-semibold text-slate-400">{{ __('nav_groups.role') }}</p>
            @foreach ($roleItems as $item)
                <a class="crm-nav-item {{ request()->routeIs($item['route']) ? 'is-active' : '' }}" href="{{ route($item['route']) }}">
                    <span aria-hidden="true">{{ $item['icon'] }}</span><span>{{ $item['label'] }}</span>
                </a>
            @endforeach
        </div>
        @endif
    </nav>

    <div class="crm-sidebar__footer"><span class="crm-status-dot" aria-hidden="true"></span>{{ __('nav.secure_workspace') }}</div>
</aside>
