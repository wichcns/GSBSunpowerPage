<?php

namespace App\Crm\Support;

class LocationTypes
{
    public const CODES = ['PETROL_STATION', 'BUSINESS_DISTRICT', 'MALL', 'OPEN_LAND', 'OTHER'];

    public static function codes(): array
    {
        return self::CODES;
    }

    public static function label(?string $code): string
    {
        return $code === null || $code === '' ? __('sites.unspecified_type') : (in_array($code, self::CODES, true) ? __('location_types.'.$code) : $code);
    }
}
